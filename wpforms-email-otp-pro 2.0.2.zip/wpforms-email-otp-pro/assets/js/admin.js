jQuery(function($) {
    console.log('WPForms Email OTP Pro admin script loaded.');

    // Toggle SMTP fields visibility
    function toggleSmtpFields() {
        const enabled = $('#wpforms-setting-smtp-enabled').is(':checked');
        $('.wpforms-setting-row-smtp-email, .wpforms-setting-row-app-password').toggle(enabled);
    }

    // Initial toggle
    toggleSmtpFields();

    // Bind change event
    $('#wpforms-setting-smtp-enabled').on('change', toggleSmtpFields);
});