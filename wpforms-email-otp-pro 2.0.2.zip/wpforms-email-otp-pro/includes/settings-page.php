<?php
namespace WPForms_Email_OTP_Pro;

// Add settings tab to WPForms settings
add_filter('wpforms_settings_tabs', function($tabs) {
    $tabs['email-otp'] = [
        'name'   => __('Email OTP', 'wpforms-email-otp-pro'),
        'form'   => true,
        'submit' => __('Save Settings', 'wpforms-email-otp-pro'),
    ];
    return $tabs;
});

// Register settings
add_action('wpforms_settings_init', function() {
    register_setting('wpforms_email_otp_pro_settings', 'wpforms_email_otp_pro_settings', function($input) {
        $sanitized = [];
        $sanitized['sender_email'] = sanitize_email($input['sender_email'] ?? '');
        $sanitized['app_password'] = sanitize_text_field($input['app_password'] ?? '');
        $sanitized['form_id'] = absint($input['form_id'] ?? 0);
        $sanitized['email_label'] = sanitize_text_field($input['email_label'] ?? '');
        $sanitized['elementor_template_id'] = absint($input['elementor_template_id'] ?? 0);
        $sanitized['otp_length'] = in_array($input['otp_length'], ['4', '6', '8']) ? $input['otp_length'] : '6';
        $sanitized['otp_expiry'] = absint($input['otp_expiry'] ?? 5);
        $sanitized['email_subject'] = sanitize_text_field($input['email_subject'] ?? '');
        $sanitized['email_message'] = wp_kses_post($input['email_message'] ?? '');
        $sanitized['smtp_enabled'] = isset($input['smtp_enabled']) ? 1 : 0;
        return $sanitized;
    });
});

// Render settings tab content
add_action('wpforms_settings_tab_content_email-otp', function() {
    $options = get_option('wpforms_email_otp_pro_settings');
    ?>
    <div class="wpforms-email-otp-pro-settings">
        <h3><?php _e('Email OTP Pro Settings', 'wpforms-email-otp-pro'); ?></h3>
        <p><?php _e('Configure the settings for Email OTP verification.', 'wpforms-email-otp-pro'); ?></p>
        <form method="post" action="options.php">
            <?php settings_fields('wpforms_email_otp_pro_settings'); ?>
            <div class="wpforms-admin-settings-email-otp">
                <?php
                wpforms_panel_field(
                    'text',
                    'wpforms_email_otp_pro_settings',
                    'sender_email',
                    [],
                    [
                        'label' => __('Sender Gmail Address', 'wpforms-email-otp-pro'),
                        'value' => $options['sender_email'] ?? '',
                    ]
                );
                wpforms_panel_field(
                    'password',
                    'wpforms_email_otp_pro_settings',
                    'app_password',
                    [],
                    [
                        'label' => __('Gmail App Password', 'wpforms-email-otp-pro'),
                        'value' => $options['app_password'] ?? '',
                    ]
                );
                wpforms_panel_field(
                    'checkbox',
                    'wpforms_email_otp_pro_settings',
                    'smtp_enabled',
                    [],
                    [
                        'label' => __('Enable SMTP', 'wpforms-email-otp-pro'),
                        'value' => isset($options['smtp_enabled']) && $options['smtp_enabled'],
                    ]
                );
                wpforms_panel_field(
                    'number',
                    'wpforms_email_otp_pro_settings',
                    'form_id',
                    [],
                    [
                        'label' => __('WPForms Form ID', 'wpforms-email-otp-pro'),
                        'value' => $options['form_id'] ?? '',
                    ]
                );
                wpforms_panel_field(
                    'text',
                    'wpforms_email_otp_pro_settings',
                    'email_label',
                    [],
                    [
                        'label' => __('Email Field Label', 'wpforms-email-otp-pro'),
                        'value' => $options['email_label'] ?? '',
                    ]
                );
                wpforms_panel_field(
                    'number',
                    'wpforms_email_otp_pro_settings',
                    'elementor_template_id',
                    [],
                    [
                        'label' => __('Elementor Template ID (optional)', 'wpforms-email-otp-pro'),
                        'value' => $options['elementor_template_id'] ?? '',
                    ]
                );
                wpforms_panel_field(
                    'select',
                    'wpforms_email_otp_pro_settings',
                    'otp_length',
                    [],
                    [
                        'label' => __('OTP Length', 'wpforms-email-otp-pro'),
                        'options' => [
                            '4' => __('4 Digits', 'wpforms-email-otp-pro'),
                            '6' => __('6 Digits', 'wpforms-email-otp-pro'),
                            '8' => __('8 Digits', 'wpforms-email-otp-pro'),
                        ],
                        'value' => $options['otp_length'] ?? '6',
                    ]
                );
                wpforms_panel_field(
                    'number',
                    'wpforms_email_otp_pro_settings',
                    'otp_expiry',
                    [],
                    [
                        'label' => __('OTP Expiry (minutes)', 'wpforms-email-otp-pro'),
                        'value' => $options['otp_expiry'] ?? '5',
                        'attributes' => ['min' => 1],
                    ]
                );
                wpforms_panel_field(
                    'text',
                    'wpforms_email_otp_pro_settings',
                    'email_subject',
                    [],
                    [
                        'label' => __('Email Subject', 'wpforms-email-otp-pro'),
                        'value' => $options['email_subject'] ?? __('Your Verification Code', 'wpforms-email-otp-pro'),
                    ]
                );
                wpforms_panel_field(
                    'textarea',
                    'wpforms_email_otp_pro_settings',
                    'email_message',
                    [],
                    [
                        'label' => __('Email Message', 'wpforms-email-otp-pro'),
                        'value' => $options['email_message'] ?? __('Your verification code is: {otp}', 'wpforms-email-otp-pro'),
                        'after' => '<p class="description">' . __('Use {otp} for the OTP code, {site} for the site name.', 'wpforms-email-otp-pro') . '</p>',
                    ]
                );
                ?>
            </div>
            <?php submit_button(__('Save Settings', 'wpforms-email-otp-pro')); ?>
        </form>
    </div>
    <?php
});