<?php
namespace WPForms_Email_OTP_Pro;

// Add settings tab to WPForms settings
add_filter('wpforms_settings_tabs', function($tabs) {
    $tabs['email-otp'] = [
        'name'   => __('Email OTP', 'wpforms-email-otp-pro'),
        'form'   => true,
        'submit' => __('Save Settings', 'wpforms-email-otp-pro'),
    ];
    return $tabs;
});

// Register settings
add_action('wpforms_settings_init', function() {
    register_setting('wpforms_email_otp_pro_settings', 'wpforms_email_otp_pro_settings', function($input) {
        $sanitized = [];
        $sanitized['sender_email'] = sanitize_email($input['sender_email'] ?? '');
        $sanitized['app_password'] = sanitize_text_field($input['app_password'] ?? '');
        $sanitized['form_id'] = absint($input['form_id'] ?? 0);
        $sanitized['email_label'] = sanitize_text_field($input['email_label'] ?? '');
        $sanitized['elementor_template_id'] = absint($input['elementor_template_id'] ?? 0);
        $sanitized['otp_length'] = in_array($input['otp_length'], ['4', '6', '8']) ? $input['otp_length'] : '6';
        $sanitized['otp_expiry'] = absint($input['otp_expiry'] ?? 5);
        $sanitized['email_subject'] = sanitize_text_field($input['email_subject'] ?? '');
        $sanitized['email_message'] = wp_kses_post($input['email_message'] ?? '');
        $sanitized['smtp_enabled'] = isset($input['smtp_enabled']) ? 1 : 0;
        return $sanitized;
    });

    // Add settings section
    add_settings_section(
        'wpforms_email_otp_pro_main',
        '',
        null,
        'wpforms-email-otp-pro'
    );

    // Sender Email
    add_settings_field(
        'sender_email',
        __('Sender Gmail Address', 'wpforms-email-otp-pro'),
        function() {
            $options = get_option('wpforms_email_otp_pro_settings');
            echo '<input type="email" name="wpforms_email_otp_pro_settings[sender_email]" value="' . esc_attr($options['sender_email'] ?? '') . '" class="wpforms-setting-field">';
        },
        'wpforms-email-otp-pro',
        'wpforms_email_otp_pro_main'
    );

    // App Password
    add_settings_field(
        'app_password',
        __('Gmail App Password', 'wpforms-email-otp-pro'),
        function() {
            $options = get_option('wpforms_email_otp_pro_settings');
            echo '<input type="password" name="wpforms_email_otp_pro_settings[app_password]" value="' . esc_attr($options['app_password'] ?? '') . '" class="wpforms-setting-field">';
        },
        'wpforms-email-otp-pro',
        'wpforms_email_otp_pro_main'
    );

    // SMTP Enabled
    add_settings_field(
        'smtp_enabled',
        __('Enable SMTP', 'wpforms-email-otp-pro'),
        function() {
            $options = get_option('wpforms_email_otp_pro_settings');
            $checked = isset($options['smtp_enabled']) && $options['smtp_enabled'] ? 'checked' : '';
            echo '<input type="checkbox" name="wpforms_email_otp_pro_settings[smtp_enabled]" id="wpforms-setting-smtp-enabled" value="1" ' . $checked . '>';
        },
        'wpforms-email-otp-pro',
        'wpforms_email_otp_pro_main'
    );

    // Form ID
    add_settings_field(
        'form_id',
        __('WPForms Form ID', 'wpforms-email-otp-pro'),
        function() {
            $options = get_option('wpforms_email_otp_pro_settings');
            echo '<input type="number" name="wpforms_email_otp_pro_settings[form_id]" value="' . esc_attr($options['form_id'] ?? '') . '" class="wpforms-setting-field">';
        },
        'wpforms-email-otp-pro',
        'wpforms_email_otp_pro_main'
    );

    // Email Field Label
    add_settings_field(
        'email_label',
        __('Email Field Label', 'wpforms-email-otp-pro'),
        function() {
            $options = get_option('wpforms_email_otp_pro_settings');
            echo '<input type="text" name="wpforms_email_otp_pro_settings[email_label]" value="' . esc_attr($options['email_label'] ?? '') . '" class="wpforms-setting-field">';
        },
        'wpforms-email-otp-pro',
        'wpforms_email_otp_pro_main'
    );

    // Elementor Template ID
    add_settings_field(
        'elementor_template_id',
        __('Elementor Template ID (optional)', 'wpforms-email-otp-pro'),
        function() {
            $options = get_option('wpforms_email_otp_pro_settings');
            echo '<input type="number" name="wpforms_email_otp_pro_settings[elementor_template_id]" value="' . esc_attr($options['elementor_template_id'] ?? '') . '" class="wpforms-setting-field">';
        },
        'wpforms-email-otp-pro',
        'wpforms_email_otp_pro_main'
    );

    // OTP Length
    add_settings_field(
        'otp_length',
        __('OTP Length', 'wpforms-email-otp-pro'),
        function() {
            $options = get_option('wpforms_email_otp_pro_settings');
            $length = $options['otp_length'] ?? '6';
            echo '<select name="wpforms_email_otp_pro_settings[otp_length]" class="wpforms-setting-field">';
            foreach (['4' => '4 Digits', '6' => '6 Digits', '8' => '8 Digits'] as $value => $label) {
                echo '<option value="' . esc_attr($value) . '" ' . selected($length, $value, false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select>';
        },
        'wpforms-email-otp-pro',
        'wpforms_email_otp_pro_main'
    );

    // OTP Expiry
    add_settings_field(
        'otp_expiry',
        __('OTP Expiry (minutes)', 'wpforms-email-otp-pro'),
        function() {
            $options = get_option('wpforms_email_otp_pro_settings');
            echo '<input type="number" name="wpforms_email_otp_pro_settings[otp_expiry]" value="' . esc_attr($options['otp_expiry'] ?? '5') . '" min="1" class="wpforms-setting-field">';
        },
        'wpforms-email-otp-pro',
        'wpforms_email_otp_pro_main'
    );

    // Email Subject
    add_settings_field(
        'email_subject',
        __('Email Subject', 'wpforms-email-otp-pro'),
        function() {
            $options = get_option('wpforms_email_otp_pro_settings');
            echo '<input type="text" name="wpforms_email_otp_pro_settings[email_subject]" value="' . esc_attr($options['email_subject'] ?? 'Your Verification Code') . '" class="wpforms-setting-field">';
        },
        'wpforms-email-otp-pro',
        'wpforms_email_otp_pro_main'
    );

    // Email Message
    add_settings_field(
        'email_message',
        __('Email Message', 'wpforms-email-otp-pro'),
        function() {
            $options = get_option('wpforms_email_otp_pro_settings');
            echo '<textarea name="wpforms_email_otp_pro_settings[email_message]" class="wpforms-setting-field large-text" rows="5">' . esc_textarea($options['email_message'] ?? 'Your verification code is: {otp}') . '</textarea>';
            echo '<p class="description">' . __('Use {otp} for the OTP code, {site} for the site name.', 'wpforms-email-otp-pro') . '</p>';
        },
        'wpforms-email-otp-pro',
        'wpforms_email_otp_pro_main'
    );
});

// Render settings tab content
add_action('wpforms_settings_tab_content_email-otp', function() {
    ?>
    <div class="wpforms-email-otp-pro-settings">
        <h3><?php _e('Email OTP Pro Settings', 'wpforms-email-otp-pro'); ?></h3>
        <p><?php _e('Configure the settings for Email OTP verification.', 'wpforms-email-otp-pro'); ?></p>
        <form method="post" action="options.php">
            <?php
            settings_fields('wpforms_email_otp_pro_settings');
            do_settings_sections('wpforms-email-otp-pro');
            submit_button(__('Save Settings', 'wpforms-email-otp-pro'));
            ?>
        </form>
    </div>
    <?php
});