<?php
/**
 * Plugin Name: WPForms Email OTP Pro
 * Description: Professional email OTP verification for WPForms with advanced settings and email templates.
 * Version: 2.0
 * Author: Adam Osama
 * Author URI: https://example.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: wpforms-email-otp-pro
 */

defined('ABSPATH') || exit;

// Define plugin constants
define('WPFORMS_EMAIL_OTP_PRO_VERSION', '2.0');
define('WPFORMS_EMAIL_OTP_PRO_FILE', __FILE__);
define('WPFORMS_EMAIL_OTP_PRO_PATH', plugin_dir_path(__FILE__));
define('WPFORMS_EMAIL_OTP_PRO_URL', plugin_dir_url(__FILE__));
define('WPFORMS_EMAIL_OTP_PRO_BASENAME', plugin_basename(__FILE__));

// Check if WPForms is active
register_activation_hook(__FILE__, 'wpforms_email_otp_pro_activate');

function wpforms_email_otp_pro_activate() {
    if (!is_plugin_active('wpforms-lite/wpforms.php') && !is_plugin_active('wpforms/wpforms.php')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            __('This plugin requires WPForms to be installed and active. Please install WPForms first.', 'wpforms-email-otp-pro'),
            __('Plugin dependency error', 'wpforms-email-otp-pro'),
            ['back_link' => true]
        );
    }
}

// Load the main plugin classes
require_once WPFORMS_EMAIL_OTP_PRO_PATH . 'includes/class-settings.php';
require_once WPFORMS_EMAIL_OTP_PRO_PATH . 'includes/class-email-sender.php';
require_once WPFORMS_EMAIL_OTP_PRO_PATH . 'includes/class-otp-handler.php';
require_once WPFORMS_EMAIL_OTP_PRO_PATH . 'includes/class-form-handler.php';
require_once WPFORMS_EMAIL_OTP_PRO_PATH . 'includes/class-admin-dashboard.php';

// Initialize the plugin
add_action('plugins_loaded', function() {
    if (!class_exists('WPForms')) {
        add_action('admin_notices', function() {
            ?>
            <div class="notice notice-error">
                <p><?php _e('WPForms Email OTP Pro requires WPForms to be installed and active.', 'wpforms-email-otp-pro'); ?></p>
            </div>
            <?php
        });
        return;
    }

    new WPForms_Email_OTP_Pro\Settings();
    new WPForms_Email_OTP_Pro\Email_Sender();
    new WPForms_Email_OTP_Pro\OTP_Handler();
    new WPForms_Email_OTP_Pro\Form_Handler();
    new WPForms_Email_OTP_Pro\Admin_Dashboard();
});

// Add settings link to plugin actions
add_filter('plugin_action_links_' . WPFORMS_EMAIL_OTP_PRO_BASENAME, function($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=wpforms-email-otp-pro') . '">' . __('Settings', 'wpforms-email-otp-pro') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
});