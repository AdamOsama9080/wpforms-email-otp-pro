jQuery(function($) {
    // Toggle SMTP fields visibility
    function toggleSmtpFields() {
        const enabled = $('#wpforms-setting-smtp-enabled').is(':checked');
        $('.wpforms-setting-smtp-email, .wpforms-setting-smtp-password').toggle(enabled);
    }

    // Initial toggle
    toggleSmtpFields();

    // Bind change event
    $('#wpforms-setting-smtp-enabled').on('change', toggleSmtpFields);

    // Form ID change handler
    $('#wpforms-setting-form-id').on('change', function() {
        const formId = $(this).val();
        if (formId) {
            // You could add AJAX here to fetch email fields for the selected form
        }
    });
});